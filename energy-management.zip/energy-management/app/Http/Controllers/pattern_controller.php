<?php

namespace App\Http\Controllers;

use App\pattern;
use App\Pattern_device;
use Illuminate\Http\Request;

use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
class pattern_controller extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }


    /*
     * function name : pattern of rationalize
     * description : this function  shaows all patterns  for user that  that exist in database
     * until user accept from  them which he want to applay
     * */

    public  function  pattern_of_rationalize()
    {

        $user_type =  Auth::user()->user_type;

        if($user_type == 'admin') {
            $pattern = pattern::all();
            $ar = Array('pattern' => $pattern);

            return view('pattern_of_rationalize', $ar);
        }
        else{




            return view('error');
        }
    }

    /**
      * function name : show event
     *
     * description : : this function show events of each pattern
     * parameter : $id of pattern
     */


    public  function  show_event($id)
    {
        $pattern = pattern::find($id);


       $pattern_device = Pattern_device::where('pattern_id', $id);


        $pattern_device = $pattern-> devices ;

        //$pattern_device = Pattern_device::where('pattern_id',$id);

       // echo $id ;
       //echo $pattern_device ;

         $ar =Array('pattern_device'=>$pattern_device);

       return view('show_event',$ar);
    }

/*
 * function name :acceptance
 *
 * description : by using this function user can accept pattern
 *
 *
 * parrameter : $id of pattern
 *
 * */





    public  function  acceptance ( $id)
    {

       $pattern = pattern::find($id);
       $pattern -> acceptance = 1;
        $pattern->save();


      return redirect('pattern_of_rationalize');

    }



    /*
 * function name : refused
 *
 * description : by using this function user can refuse  pattern
 *
 *
 * parrameter : $id of pattern
 *
 * */

    public function  refused($id)
    {


        $pattern = pattern::find($id);
        $pattern -> acceptance = 0;
        $pattern->save();


        return redirect('pattern_of_rationalize');


    }



}
