<?php

namespace App\Http\Controllers;

use App\group;
use App\User;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\device;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Auth;

class dcon extends Controller
{
    //

    /*
     *
     *
     *
     * */
    public function __construct()
    {
        $this->middleware('auth');
    }





    /*
     *   this function :control return  assign devices of each user
     *
     * take user id from session that store the user who do login
     *
     *
     * */
    public function  control()
    {
       /*$respt="";

       $arr =array('respt'=>$respt);
        return view("control",$arr);*/
        $id = Auth::user()->id;

        $user = User::find($id);
       $devices = $user ->devices ;

       //echo  $devices ;

        $arr =Array('devices'=>$devices);

     return view('control_on_device',$arr);
    }



    /**
     function name : store
     * description : by this function user can controlling on devices that admin assign to the user
     * and  send http request to gateway  if recieved response change sate of device in the data base
     *
     * parameter : device id  , state
     */


public function store($id , $action )
{

  if($action=='on')
   {


       $client = new Client();

       $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
           'json' => ['device_id' =>$id,'device_state'=>'1']
       ]);

       if($response)
       {
           $newdevice = device::find($id);
           $newdevice->current_state = 1;

           $newdevice->save();


       }


    }
    elseif ($action == 'off')
     {


         $client = new Client();

         $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
             'json' => ['device_id' => $id,'device_state'=>'0']
         ]);

         if($response) {
             $newdevice = device::find($id);
             $newdevice->current_state = 0;

             $newdevice->save();

         }


      }


    return redirect('control');

}










   /* public function store($action){

      if($action =='1off')
      {
        $newdevice = device::find(1);
        $newdevice->current_state = 0;

          $newdevice->save();






          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '1','device_state'=>'0']
          ]);




        return redirect('control');
      }
      elseif ($action =='1on')
      {
          $newdevice = device::find(1);
          $newdevice->current_state = 1;

          $newdevice->save();




          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '1','device_state'=>'1']
          ]);

          if($response)
          {

              return redirect('control');

          }
           else{



               return redirect('control');

           }


      }
      elseif ($action =='2off')
      {

          $newdevice = device::find(2);
          $newdevice->current_state = 0;

          $newdevice->save();



          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '2','device_state'=>'0']
          ]);


          return redirect('control');

      }
      elseif ($action =='2on')
      {

          $newdevice = device::find(2);
          $newdevice->current_state = 1;

          $newdevice->save();



          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '2','device_state'=>'1']
          ]);

         return  redirect('control');
      }
      elseif ($action == '3off')
      {
          $newdevice = device::find(3);
          $newdevice->current_state = 0;

          $newdevice->save();

          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '3','device_state'=>'0']
          ]);

          return redirect('control');
      }
      elseif ($action == '3on')
      {

          $newdevice = device::find(3);
          $newdevice->current_state = 1;

          $newdevice->save();

          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '3','device_state'=>'1']
          ]);
          return redirect('control');

      }





    }*/





    public  function control_on_groups( )
    {

        $id = Auth::user()->id;





        $user = User::find($id);


        $user_groups =  $user-> groups ;



        $ar =Array('user_groups'=>$user_groups);

        return view('control_on_groups',$ar);

    }



/*
 * function name : group_con
 *
 *this function used to  enable user to contrl group that admi assign to user  eithe on or off
 *
 * parameter : $name of  group and $sate that user want to change to
 *
 * this function send to gateway  http request to change state of device in node  if it  recieve  response change this state
 * in the data base
 *
 *
 * */



    public  function  group_con($name ,$state)
    {

       echo $name ;

        $group = group::where('name',$name)->first();

         $devices = $group->devices;

        if($state=='on')
        {



            $client = new Client();

            $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
                'json' => ['group_name' => $name ,'state'=>'0']
            ]);

            if($response) {

                foreach ($devices as $dev) {

                    // echo $dev->current_state ;

                    $dev->current_state = 1;

                    $dev->save();
                }

                return redirect('control_on_groups');
            }

            else
            {

                return redirect('control_on_groups');

            }
        }

        elseif ($state =='off')
        {

            $client = new Client();

            $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
                'json' => ['group_name' => $name ,'state'=>'0']
            ]);

            if($response) {
                foreach ($devices as $dev) {

                    echo $dev->current_state;

                    $dev->current_state = 0;

                    $dev->save();
                }

                return redirect('control_on_groups');
            }

            else{



                return redirect('control_on_groups');
            }


    }

    }








}
