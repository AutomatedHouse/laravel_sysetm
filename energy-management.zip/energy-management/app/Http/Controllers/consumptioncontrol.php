<?php

namespace App\Http\Controllers;

use App\consumption;
use App\device;
use Illuminate\Http\Request;

use App\Http\Requests;
use PhpParser\Node\Expr\Array_;

class consumptioncontrol extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }
       /*

        function name :  device_consumption
       description : show all devices  until  user select device to see consumption of it
        parameter : no
       */
    public function device_consumption()
    {


        $devices =device::all();
        $ar = Array('devices'=>$devices);

        return view('consumption_devices',$ar);
    }


    /**
     function name : consumption_each_dev
     *
     * description : show consumption of  selected device
     *
     * parameter : $id  refere to device id
     *
     */

    public function consumption_each_dev($id)
    {


        $devic = device::find($id);

        $consume = $devic->consumption ;

        $ar =Array('consume'=>$consume);

        return view('show_consumption' ,$ar);

    }



}
