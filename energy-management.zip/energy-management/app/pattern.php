<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pattern extends Model
{
    //
    public  $table ='paterns';
    public  $timestamps = false;

   /*  each pattern  has one device which we refere to as action          */

    public function device()
    {

        return $this->belongsTo('App\device');


    }

/*
 * each pattern has  many device which refere to has many events
 *
 *
 * */

    public function  devices()
    {


        return $this->belongsToMany('App\device');
    }






}
