<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class device extends Model
{
    // class of device
    // table of this class in database called devices
    public $table='devices';
   // each device belong to  many groups or has many groups
    public  function  groups()
    {
        return $this->belongsToMany('App\group');
    }

    /*
     *
     * each device has many consumptions (interprete the  reelationship 1:n)
     *
     * */
    public  function  consumption()
    {
        return   $this->hasMany('App\consumption');
    }

   /*
    *
    * each device has many patterns (interperate  of relationship  1:n )
    *
    * */
    public  function  patterns()
    {
        return $this->hasMany('App\pattern');
        //return pattern::where('action_id',$this->id);
    }



   /*
    *
    * each device is controlled on by many users
    *
    *  interperate for relationship (n:n)
    * */
    public function  users()
    {


        return $this->belongsToMany('App\user');
    }







}
