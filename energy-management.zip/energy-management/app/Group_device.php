<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Group_device extends Model
{  // table of this class in the database
    public $table='device_group';
    //
}
