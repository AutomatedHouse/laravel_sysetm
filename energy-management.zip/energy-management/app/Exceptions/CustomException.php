<?php
namespace  App\Exceptions;

class CustomException extends \Exception {














}