<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pattern_device extends Model
{
    //
    public $table ='device_pattern';
    public $timestamps =false ;
}
