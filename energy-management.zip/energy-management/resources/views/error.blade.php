





you must assign once  device to user