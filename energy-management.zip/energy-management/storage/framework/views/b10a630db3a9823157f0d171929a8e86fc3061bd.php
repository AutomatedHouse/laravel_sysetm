/

<?php $__env->startSection('content'); ?>


    <form  method="post" action="/grouping">

        <?php echo e(csrf_field()); ?>

        &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
         <input type="text"  name="group_name" placeholder="group name" height="200">

        <?php if($errors->has('group_name')): ?>
            <span class="help-block">
                                        <strong><?php echo e($errors->first('group_name')); ?></strong>
                                    </span>
            <?php endif; ?>
            </div>
            </div>
        <br/>
        <br/>


        &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
        <textarea name="description" placeholder="group description" width="300" ></textarea>




            <?php if($errors->has('description')): ?>
                <span class="help-block">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                <?php endif; ?>
                </div>
                </div>

          &nbsp;&nbsp;
        <br/>
        &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


        <input type="submit" value="add" name="adding" width="100">

    </form>








    <center>

        <table   border="" >
            <tr>
                <td>

                </td>

                <td>
                    group name
                </td>

                <td>

                    &nbsp;    &nbsp;

                </td>

                <td>
                     description

                </td>

              <td>
                 updating
              </td>

                <td>
                    assign device to group
                </td>

                <td>
                    assign group to user
                </td>


            </tr>

            <?php foreach($allgroup as $algr): ?>




                <tr>
                    <td>

                    </td>

                    <td>
                        <?php echo e($algr->name); ?>

                    </td>

                    <td>

                    </td>


                    <td>
                        <?php echo e($algr->description); ?>


                    </td>


                    <td>
                        <a href="/update_group/<?php echo e($algr->id); ?>">update</a>
                    </td>

                    <td>
                        <a href="/assign_device/<?php echo e($algr->id); ?>">assign device </a>
                    </td>

                    <td>
                        <a href="/group_user/<?php echo e($algr->id); ?>">assign users </a>
                    </td>




            <?php endforeach; ?>










        </table>

    </center>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>