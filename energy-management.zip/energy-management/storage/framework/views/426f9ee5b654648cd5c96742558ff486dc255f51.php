<?php $__env->startSection('content'); ?>


<?php foreach($dev as  $v): ?>



    <tr>
        <td>
            <img src="pictures/lamp.jpg" height="100" width="100" />


        </td>
        <td>
            &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;
        </td>

        <td>
            <?php echo e($v->name); ?>

        </td>
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        <td>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        </td>
        <td>

            <a href="/assign_device_user/<?php echo e($v-> id); ?>"> assign user to this device </a>

        </td>


    </tr>

<?php endforeach; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>