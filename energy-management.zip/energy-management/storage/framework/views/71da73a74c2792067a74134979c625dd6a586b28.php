<?php $__env->startSection('content'); ?>





<center>
    <?php foreach($pattern_device as  $v): ?>


        <img src="pictures\3.jpg" height="100" width="100" />
        &nbsp;&nbsp;&nbsp;


        <?php echo e($v->name); ?>


        <br/>
        <br/>
        <br/>

    <?php endforeach; ?>

    <a href="/pattern_of_rationalize">  previous page</a>
</center>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>