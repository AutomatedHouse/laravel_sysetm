/

<?php $__env->startSection('content'); ?>



    <input name="group_name" value="<?php echo e($device->name); ?>"  >

    <form  method="post" action="/assign_device_user/<?php echo e($device->id); ?>">

        <?php echo e(csrf_field()); ?>

        <br/><br/>
        &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
        user mail :  <select  name="user_email">

            <?php foreach($user as $dev): ?>
                <option value="<?php echo e($dev->email); ?>"><?php echo e($dev->email); ?></option>


            <?php endforeach; ?>
        </select>

        <?php if($errors->has('user_email')): ?>
            <span class="help-block">
                                        <strong><?php echo e($errors->first('user_email')); ?></strong>
                                    </span>
            <?php endif; ?>
            </div>
            </div>


            &nbsp;&nbsp;&nbsp;&nbsp;





            <input type="submit" value="add user to this group " name="adding" width="100">

    </form>







    <center>

        <table   border="" >
            <tr>
                <td>

                </td>

                <td>
                    first name
                </td>

                <td>

                    &nbsp;    &nbsp;

                </td>

                <td>
                    email

                </td>






            </tr>

            <?php foreach($user_device as $v): ?>




                <tr>
                    <td>

                    </td>

                    <td>
                        <?php echo e($v->name); ?>

                    </td>

                    <td>

                    </td>


                    <td>
                        <?php echo e($v->email); ?>


                    </td>






            <?php endforeach; ?>










        </table>

    </center>








    <a href="/devices">  return to the previous page   </a>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>