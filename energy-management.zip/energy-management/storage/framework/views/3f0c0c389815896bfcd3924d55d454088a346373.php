<?php $__env->startSection('content'); ?>



    <?php foreach($devices as $device): ?>

        <div  class="form-group" >

            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp;
            <img src="pictures\lamp.jpg" value="first device " height="100" width="100" />
            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;


                <a class="btn btn-primary"   href="store/<?php echo e($device->id); ?>/<?php echo e($action='on'); ?>">
                    <i class="fa fa-btn fa-user"></i> open device <?php echo e($device->id); ?>

                </a>
                &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
                &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;

                <a class="btn btn-primary"   href="store/<?php echo e($device->id); ?>/<?php echo e($action='off'); ?>">
                    <i class="fa fa-btn fa-user"></i> close device <?php echo e($device->id); ?>

                </a>





        </div>



        &nbsp;   &nbsp; &nbsp;   &nbsp;



    <?php endforeach; ?>

    <a href="/control_on_groups">  to control on your group click here .</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>