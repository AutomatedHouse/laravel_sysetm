<?php $__env->startSection('content'); ?>





    <center>
        <table  border="5"  >


            <tr>
                <td>
                    pattern action

                </td>

                <td>

                </td>

                <td>
                    pattaern state
                </td>


                <td>

                </td>
                <td>
                    click to see  device open in pattern

                </td>

                <td>

                </td>

                <td>
                    acceptance

                </td>


                <td>

                </td>

                <td>

                    refused
                </td>





            </tr>

            <?php foreach($pattern as $pater): ?>


                <tr>


                    <td>   device <?php echo e($pater->device_id); ?>      </td>


                    <td>

                    </td>


                    <td>

                        <?php if($pater->acceptance == 1): ?>
                            accepted

                        <?php elseif($pater->acceptance == 0): ?>

                            refused

                         <?php endif; ?>
                    </td>


                    <td>

                    </td>


                    <td>  <a href="/show_event/<?php echo e($pater->id); ?>"> see open devices  </a>      </td>

                    <td>

                    </td>
                    <td>  <a href="/acceptance/<?php echo e($pater->id); ?>">  acceptance </a>       </td>

                    <td>

                    </td>
                    <td>

                        <a href="/refused/<?php echo e($pater->id); ?>">  refused </a>

                    </td>



                </tr>



            <?php endforeach; ?>

        </table>

        <a href="/"> previous page </a>

    </center>


















<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>