/

<?php $__env->startSection('content'); ?>



    <input name="group_name" value="<?php echo e($group->name); ?>"  >

    <form  method="post" action="/assign_device/<?php echo e($group->id); ?>">

        <?php echo e(csrf_field()); ?>

        <br/><br/>
        &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;
        device name :  <select  name="device_name">

            <?php foreach($alldevices as $dev): ?>
            <option value="<?php echo e($dev->name); ?>"><?php echo e($dev->name); ?></option>


            <?php endforeach; ?>
        </select>

        <?php if($errors->has('device_name')): ?>
            <span class="help-block">
                                        <strong><?php echo e($errors->first('device_name')); ?></strong>
                                    </span>
            <?php endif; ?>
            </div>
            </div>


            &nbsp;&nbsp;&nbsp;&nbsp;





                <input type="submit" value="add device to this group " name="adding" width="100">

    </form>







    <center>

        <table   border="" >
            <tr>
                <td>

                </td>

                <td>
                    group devices
                </td>

                <td>

                    &nbsp;    &nbsp;

                </td>

                <td>
                    description

                </td>






            </tr>

            <?php foreach($value as $v): ?>




                <tr>
                    <td>

                    </td>

                    <td>
                        <?php echo e($v->name); ?>

                    </td>

                    <td>

                    </td>


                    <td>
                        <?php echo e($v->description); ?>


                    </td>






            <?php endforeach; ?>










        </table>

    </center>








    <a href="/grouping">  return to the previous page   </a>



   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>