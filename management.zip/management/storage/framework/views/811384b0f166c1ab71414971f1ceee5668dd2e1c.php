/

<?php $__env->startSection('content'); ?>



<?php foreach($devices as $device): ?>








                <img src="pictures/lamp.jpg" height="100" width="100" />

                <a href="/consumption_of_specific/<?php echo e($device->id); ?>">  show consumption of this device <?php echo e($device->name); ?>   </a>

               <br/>



<?php endforeach; ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>