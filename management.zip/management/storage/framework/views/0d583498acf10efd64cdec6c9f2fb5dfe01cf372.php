/

<?php $__env->startSection('content'); ?>
    <center>

    <table>
        <tr>
           <td>
               picture of  device
           </td>
            <td>
                &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;
            </td>

            <td>
                name
            </td>
            <td>
            </td>

            <td>
                current state
            </td>




        </tr>


        <?php foreach($device as  $viewdevice): ?>



            <tr>
                <td>
                    <img src="pictures/lamp.jpg" height="100" width="100" />


                </td>
                <td>
                    &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;  &nbsp;&nbsp;
                </td>

                <td>
                    <?php echo e($viewdevice->name); ?>

                </td>
                       &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                <td>
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                </td>
                <td>


                     <?php if($viewdevice->current_state == 0 ): ?>

                         OFF
                         <?php endif; ?>
                     <?php if($viewdevice->current_state == 1): ?>
                         ON
                         <?php endif; ?>

                </td>


            </tr>

        <?php endforeach; ?>


    </table>

    </center>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>