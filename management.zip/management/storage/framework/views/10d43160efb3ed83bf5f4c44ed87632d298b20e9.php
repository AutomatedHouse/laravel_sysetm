/

<?php $__env->startSection('content'); ?>


    <!--  <table> -->



            <?php foreach($user_groups as  $v): ?>
                <br/> <br/>
                  &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

                        <img src="pictures/2.jpg" height="100" width="100" />


                &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

                        <?php echo e($v->name); ?>


                &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

                  <a class="btn btn-primary"   href="group_con/<?php echo e($v->name); ?>/<?php echo e($state='on'); ?>">
                      <i class="fa fa-btn fa-user"></i> open
                  </a>
                  &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
                  &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
                  &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
                  &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;


                  <a class="btn btn-primary"   href="group_con/<?php echo e($v->name); ?>/<?php echo e($state='off'); ?>">
                      <i class="fa fa-btn fa-user"></i> close
                  </a>

                  &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
                  &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
                  &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;











                  &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
                  &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
                  &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp;





            <?php endforeach; ?>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>