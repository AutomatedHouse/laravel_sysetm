<?php $__env->startSection('content'); ?>

    <center>
    <table  border="5"  >


        <tr>
          <td>
            consumption of hour

          </td>

            <td>

            </td>


            <td>
                  consumption  amount

            </td>

            <td>

            </td>

            <td>
                consumption  cost L.E

            </td>


            <td>

            </td>





        </tr>

    <?php foreach($consume as $consum): ?>


     <tr>


         <td>  <?php echo e($consum->consumption_hour); ?>      </td>


         <td>

         </td>

         <td>  <?php echo e($consum->consumption_amount); ?>      </td>

         <td>

         </td>
         <td>  <?php echo e($consum->consumption_cost); ?>        </td>

         <td>

         </td>



     </tr>



    <?php endforeach; ?>

    </table>

        <a href="/consumption"> previous page </a>

    </center>







   




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>