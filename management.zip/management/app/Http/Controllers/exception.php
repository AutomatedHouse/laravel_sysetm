<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class exception extends Controller
{
    //



    public  function  exception1()
    {



        return view('exception1');
    }
}
