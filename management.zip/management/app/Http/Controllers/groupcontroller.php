<?php


namespace App\Http\Controllers;

use App\consumption;
use App\device;
use App\Device_user;
use App\group;
use App\Group_device;
use App\Group_user;
use App\Notification;
use App\Notification_user;
use App\pattern;
use App\Pattern_device;
use App\Pattern_event;
use App\Timestamp;
use App\Timestamps_consumption;
use App\User;
use Illuminate\Http\Request;
use Carbon\Carbon;



use App\Http\Requests;

use App\Exceptions\CustomException;


class groupcontroller extends Controller
{
    //



    public function  testing()
    {

        try
        {


            $x = User::find('mostafa');
            throw new CustomException();
            // echo $x;

        } catch (Exception $e)
        {

         throw new CustomException($e->getMessage());

        }



    }


// i did this control for testing
    public function test (/*group $SA , device $d */)
    {

      /* $x = pattern::find(1);
         $y =  $x->devices ;
          dd($y);*/

     /* $consumption =  new consumption();
      $consumption->consumption_amount = 4.5 ;
      $consumption->consumption_cost = 10.5 ;
      $consumption->device_id= 1 ;
      $consumption->save();

        $consumption1 =  new consumption();
        $consumption1->consumption_amount = 8.5 ;
        $consumption1->consumption_cost = 9.5 ;
        $consumption1->device_id= 2;
        $consumption1->save();


        $consumption2 =  new consumption();
        $consumption2->consumption_amount = 11.5 ;
        $consumption2->consumption_cost = 11.85 ;
        $consumption2->device_id= 3;
        $consumption2->save();*/

       /* $timestamp_consumption = new Timestamps_consumption();

        $timestamp_consumption -> consumption_id = 1;
        $timestamp_consumption ->timestamp_id =1 ;

        $timestamp_consumption->save();

        $timestamp_consumption1 = new Timestamps_consumption();

        $timestamp_consumption1 -> consumption_id = 2;
        $timestamp_consumption1 ->timestamp_id =1 ;

        $timestamp_consumption1 ->save();
        $timestamp_consumption3 = new Timestamps_consumption();

        $timestamp_consumption3 -> consumption_id = 3;
        $timestamp_consumption3 ->timestamp_id =1 ;

        $timestamp_consumption3 ->save();*/

     /*$not = new Notification_user();
     $not->notification_id = 1;
     $not->user_id = 1 ;
     $not->save();*/
    /* $n =Notification::find(1);
     $c = $n->users;*/

    $u =User::find(1);
    $c = $u->notifications;
     dd($c);

        echo"goooooooooooooood";



       // $SA->name ='mohame';
       // $SA->description ='hello mr mohamed';

       // echo $SA->name ;
       // echo  $SA->description;
    /*    $dev = new device();



           $dev->name = 'device 2';
           $dev->description ='this is second  device ';
           $dev->current_state =0;
           $dev->save();
           $gro =new group();
           $gro->name ='lighting';
           $gro->description ='this is group of lighting ';
           $gro->save();
           $gpd = new Group_device();
           $gpd->device_id = $dev->id;
           $gpd->group_id = $gro->id;
           $gpd->save();*/
         // $s = group::find(1);
          //echo  $s-> devices ;

      //  $gpd  =Group_device::find(1);
        //echo $newdevice -> users ;




       /* $d = new Group_user();
        $d->user_id = 2;
        $d->group_id = 1 ;
        $d->save();
        $newdevice = group::find(1);
        echo $newdevice -> users ;*/

       /* $cons = new consumption();
        $cons->device_id =1 ;
        $cons->consumption_cost =2000;
        $cons->consumption_amount =2000;
        $cons->save();*/

       // $current_time ='0000-00-00 00:00:00'->toDayDateTimeString();
        ////$dtime = DateTime::createFromFormat("y/m/d G:i", "2017-04-19 23:34:27");
       // $timestamp = $dtime->getTimestamp();
         //$cons = new consumption();
        //$cons->consumption_hour =$current_time;
       // $cons->device_id =1 ;
       // $cons->consumption_cost =2000;
       // $cons->consumption_amount =2000;
       // $cons->save();
      // $con = consumption::find($current_time);

        /*$patterm =new pattern();
        $patterm->action_id =1;
        $patterm->acceptance =1;
        $patterm->confidence = 10 ;
        $patterm->support =10;
        $patterm->save;*/
         /*$pattern_device = new Pattern_device();

       $pattern_device->device_id =2;
        $pattern_device->pattern_id =2 ;
        $pattern_device->save();*/

      /* $t =new  Device_user();
       $t->device_id = 1 ;
       $t->user_id = 1;
       $t->save();*/
       //$d = device::find(1);

       // echo $d->users;
        //$f =user::find(2);
        //echo  $f->devices  ;


       // $people = User::find(1);

       //echo  $people ->devices ;



        //  foreach ($newdevice -> devices  as $v )
         //  echo $v.name;
        //echo $gpd;

       // $recommend =  new recomendation();


       //$this->recommend();

       // $arr =
       //  $dev = $arr['array'];
       //  $pattern = $arr['pattern'];





    }










    public  function  recommend( )
    {

        $devices_arr = device::all();

         $array = array();
        foreach ($devices_arr as $dev)
        {

              //array_add( $myarray ,$dev->id , $dev->current_state );
             //$myarray =  array_push( $dev->id =>  );

            $array[$dev->id] = $dev->current_state  ;


        }


        $pattern  = pattern::all();



      //  $ar = array( 'array'=> $array ,'pattern' => $pattern );
        $claculation = array();

      foreach ( $pattern as $p)
      {


          $events =  $p->devices  ;

          if(reset($events) != null) {
              $ar = array('array' => $array, 'events' => $events);

              $v = $this->check_pattern($ar);
          }
          else
          {


              $v =0 ;
          }

          if($v == 1)
          {
              echo $p->device_id;
              if( $array[$p->device_id] != 0  )
              {
                  $claculation[$p->id] = $p -> confidence ;

                  //echo  $p -> confidence ;

              }

          }



      }




        $maximum = max($claculation);
      //$c=array (1=> 20 , 2=>50);

        //$maximum = max($maximum);
        $key = array_search ( $maximum ,$claculation);

        $pater_s =pattern::where('id',$key)->first();

        $showing = 'you shold close device '. $pater_s->device_id ;
        //echo  $showing  ;





    }





    public  function  check_pattern($ar)
    {

       $events =  $ar['events'];

       $array_devices =$ar['array'];

       foreach ( $events  as $event)
       {

           if($array_devices[$event->id]  == 0  )
           {

               return 0 ;

           }
             elseif (is_null($event) )
             {


                 return 0 ;

             }



       }


        return 1 ;


    }





}
