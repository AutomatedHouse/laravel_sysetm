<?php

namespace App\Http\Controllers;

use App\device;
use Illuminate\Http\Request;

use App\Http\Requests;

class monitoring extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }


    /*
     * function name  :  mon
     * description : by this function user can monitor all devices
     *
     * */

    public function  mon()
    {

       $device = device::all();

       // array con tain all devices  to show in view mon
        $arr = Array('device'=>$device);

        return view("mon",$arr);
    }





}
