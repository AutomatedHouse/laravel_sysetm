<?php

namespace App\Http\Controllers;

use App\group;
use App\User;
use Illuminate\Http\Request;
use App\pattern;

use App\Http\Requests;
use App\device;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Auth;
use DB ;

class dcon extends Controller
{
    //

    /*
     *
     *
     *
     * */
    public function __construct()
    {
        $this->middleware('auth');
    }





    /*
     *   this function :control return  assign devices of each user
     *
     * take user id from session that store the user who do login
     *
     *
     * */
    public function  control()
    {
       /*$respt="";

       $arr =array('respt'=>$respt);
        return view("control",$arr);*/
        $id = Auth::user()->id;

        $user = User::find($id);
       $devices = $user ->devices ;

       //echo  $devices ;

        $arr =Array('devices'=>$devices);

     return view('control_on_device',$arr);
    }



    /**
     function name : store
     * description : by this function user can controlling on devices that admin assign to the user
     * and  send http request to gateway  if recieved response change sate of device in the data base
     *
     * parameter : device id  , state
     */


public function store($id , $action )
{

  if($action=='on')
   {


       $client = new Client();

       $response = $client->post('flow-app.eu-gb.mybluemix.net/device_control', [
           'json' => ['device_id' =>$id,'device_state'=>'1']
       ]);

       if($response)
       {
           $newdevice = device::find($id);
           $newdevice->current_state = 1;

           $newdevice->save();


       }


    }
    elseif ($action == 'off')
     {


         $client = new Client();

         $response = $client->post('flow-app.eu-gb.mybluemix.net/device_control', [
             'json' => ['device_id' => $id,'device_state'=>'0']
         ]);

        if($response) {
             $newdevice = device::find($id);
             $newdevice->current_state = 0;

             $newdevice->save();

         }


      }


    //return redirect('control');





    $recommending = $this ->recommend();


    if ($recommending  != null) {
        echo "success";

        $notification = array(
            'message' => $recommending ,
            'alert-type' => 'success'
        );

    }
    //elseif ($recommending)

    return back()->with($notification);








}










   /* public function store($action){

      if($action =='1off')
      {
        $newdevice = device::find(1);
        $newdevice->current_state = 0;

          $newdevice->save();






          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '1','device_state'=>'0']
          ]);




        return redirect('control');
      }
      elseif ($action =='1on')
      {
          $newdevice = device::find(1);
          $newdevice->current_state = 1;

          $newdevice->save();




          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '1','device_state'=>'1']
          ]);

          if($response)
          {

              return redirect('control');

          }
           else{



               return redirect('control');

           }


      }
      elseif ($action =='2off')
      {

          $newdevice = device::find(2);
          $newdevice->current_state = 0;

          $newdevice->save();



          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '2','device_state'=>'0']
          ]);


          return redirect('control');

      }
      elseif ($action =='2on')
      {

          $newdevice = device::find(2);
          $newdevice->current_state = 1;

          $newdevice->save();



          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '2','device_state'=>'1']
          ]);

         return  redirect('control');
      }
      elseif ($action == '3off')
      {
          $newdevice = device::find(3);
          $newdevice->current_state = 0;

          $newdevice->save();

          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '3','device_state'=>'0']
          ]);

          return redirect('control');
      }
      elseif ($action == '3on')
      {

          $newdevice = device::find(3);
          $newdevice->current_state = 1;

          $newdevice->save();

          $client = new Client();

          $response = $client->post('flow-app.eu-gb.mybluemix.net/test1?', [
              'json' => ['device_id' => '3','device_state'=>'1']
          ]);
          return redirect('control');

      }





    }*/


   ///// recommmendation



    public  function  recommend( )
    {

        $devices_arr = device::all();

        $array = array();
        foreach ($devices_arr as $dev)
        {



            $array[$dev->id] = $dev->current_state  ;


        }


        $pattern  = pattern::all();




        foreach ($pattern as $op)
        {

            echo $op;
        }



        $claculation = array();

        foreach ( $pattern as $p)
        {

             if($p->acceptance == 1) {

                 $events = $p->devices ;
                 //dd($events);




                 if (reset($events) != null) {
                    // dd($events);
                     $ar = array('array' => $array, 'events' => $events);

                     $v= $this->check_pattern($ar);
                     echo 'no' ;
                 } else {


                     $v = 0;
                     echo 'hello';
                 }
                 echo $v ;
                 //dd($v);
                 if ($v == 1) {

                     if ($array[$p->device_id] != 0) {
                         $claculation[$p->id] = $p->confidence;



                     }

                 }


             }
        }


         if(!empty($claculation)) {

             $maximum = max($claculation);


             $key = array_search($maximum, $claculation);

             $pater_s = pattern::where('id', $key)->first();
            ;

             $showing = 'you shold close device ' . $pater_s->device_id . "according to pattern " . $key . "you accepted ";

             return  $showing ;
         }

        $showing = 'there is no recommend pattern  ' ;
        return $showing;


    }





    public  function  check_pattern($ar)
    {
        //dd($ar);
        $events =  $ar['events'];
      //echo $events  ;

        $array_devices =$ar['array'];

        foreach ( $events  as $event)
        {

            if($array_devices[$event->id]  == 0  )
            {

                return 0 ;

            }
            elseif (is_null($event) )
            {


                return 0 ;

            }



        }


        return 1 ;


    }












    // recommend end



    public  function control_on_groups( )
    {

        $id = Auth::user()->id;





        $user = User::find($id);


        $user_groups =  $user-> groups ;



        $ar =Array('user_groups'=>$user_groups);

        return view('control_on_groups',$ar);

    }



/*
 * function name : group_con
 *
 *this function used to  enable user to contrl group that admi assign to user  eithe on or off
 *
 * parameter : $name of  group and $sate that user want to change to
 *
 * this function send to gateway  http request to change state of device in node  if it  recieve  response change this state
 * in the data base
 *
 *
 * */



    public  function  group_con($name ,$state)
    {

       echo $name ;

        $group = group::where('name',$name)->first();

         $devices = $group->devices;
         //dd($devices);

         $devicesaccess = array();


         foreach ($devices  as $d)
         {


             array_push($devicesaccess, $d->id);


         }


   //dd($devicesaccess);


        if($state=='on')
        {



            $client = new Client();



            foreach ($devicesaccess as $devices_id )
            {
                $response = $client->post('flow-app.eu-gb.mybluemix.net/device_control', [
                    'json' => ['devices_id' => $devices_id  ,'state'=>'1']
                ]);
               // dd($devicesaccess );


                if($response) {

                    //   foreach ($devices as $dev) {
                    //$device = device::where('id', $devices_id)->first();
                    $device = device::find($devices_id);
                   // dd( $device);

                    // echo $dev->current_state ;

                    $device->current_state = 1;

                    $device->save();
                    // }

                }

                else{



                    return redirect('control_on_groups');
                }

            }

            /*$response = $client->post('flow-app.eu-gb.mybluemix.net/device_control', [
                'json' => ['devices_id' => $devices_id  ,'state'=>'1']
            ]);*/

          /*  if($response) {

                foreach ($devices as $dev) {

                    // echo $dev->current_state ;

                    $dev->current_state = 1;

                    $dev->save();
                }*/
            return redirect('control_on_groups');

            }




        elseif ($state =='off') {

            $client = new Client();


            foreach ($devicesaccess as $devices_id) {
               // dd($devices_id);
                $response = $client->post('flow-app.eu-gb.mybluemix.net/device_control', [
                    'json' => ['devices_id' => $devices_id, 'state' => '0']
                ]);


                if ($response) {

                    //   foreach ($devices as $dev) {
                    $device = device::find($devices_id);
                    //$device = device::where('id', $devices_id)->first();


                    // echo $dev->current_state ;

                    $device->current_state = 0;

                    $device->save();
                    // }


                }


                else{



                    return redirect('control_on_groups');
                }
            }
            /*$response = $client->post('flow-app.eu-gb.mybluemix.net/device_control', [
                'json' => ['devices_id' => $devices_id  ,'state'=>'0']
            ]);

            if($response) {
                foreach ($devices as $dev) {

                    echo $dev->current_state;

                    $dev->current_state = 0;

                    $dev->save();
                }

                return redirect('control_on_groups');
            }*/

           /* else{



                return redirect('control_on_groups');
            }*/
            return redirect('control_on_groups');

    }

    }








}
