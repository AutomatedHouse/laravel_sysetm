<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Device_user extends Model
{
    // class of device user
    // table of this class in the database
    public  $table='device_user';
    public  $timestamps=false;

}
