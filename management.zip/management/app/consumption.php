<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class consumption extends Model
{
    // class of cunsmption
     public $timestamps=false;

     // table of this class in database called  consumptions
     public $table='consumptions';
   // public  $= false;


    /*
     * each con sumption belong to one device
     *
     * */
    public  function  device()
    {


        return $this->belongsTo('App\device');
    }


    public  function  timestamp()
    {


        return $this->belongsToMany('App\Timestamp');
    }

    // Timestamp

}
