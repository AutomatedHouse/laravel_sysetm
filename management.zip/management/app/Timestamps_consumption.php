<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Timestamps_consumption extends Model
{
    //
    public $table ='consumption_timestamp';
    public $timestamps = false;
}
