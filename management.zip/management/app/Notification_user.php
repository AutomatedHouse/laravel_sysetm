<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notification_user extends Model
{
    //

    public $table ='notification_user';
    public  $timestamps=false;
}
