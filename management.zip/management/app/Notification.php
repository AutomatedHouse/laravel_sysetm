<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    //
    public $table ='notifications';



    public function  users()
    {


        return $this->belongsToMany('App\user');
    }



}
