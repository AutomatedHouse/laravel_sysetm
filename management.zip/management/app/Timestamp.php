<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Timestamp extends Model
{
    //
    public  $table='timestamps';
    public $timestamps=false;

    public function  consumption()
    {


        return $this->belongsToMany('App\consumption');
    }
}
