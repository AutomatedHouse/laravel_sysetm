<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class group extends Model
{
    //class of group

    public $table ='groups';

    /*
     * each group has many devices
     *
     *
     * */

    public function  devices()
    {


        return $this->belongsToMany('App\device');
    }
      /*
       * each group has many user
       *
       *
       * */

    public function  users()
    {


        return $this->belongsToMany('App\user');
    }


}
