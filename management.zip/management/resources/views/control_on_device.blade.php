@extends('layouts.app')

@section('content')



    @foreach($devices as $device)

        <div  class="form-group" >

            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp;
            <img src="pictures\lamp.jpg" value="first device " height="100" width="100" />
            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
            &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;


                <a class="btn btn-primary"   href="store/{{$device->id}}/{{$action='on'}}">
                    <i class="fa fa-btn fa-user"></i> open device {{$device->id}}
                </a>
                &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;
                &nbsp; &nbsp;   &nbsp; &nbsp;  &nbsp; &nbsp;   &nbsp; &nbsp; &nbsp; &nbsp;   &nbsp; &nbsp;

                <a class="btn btn-primary"   href="store/{{$device->id}}/{{$action='off'}}">
                    <i class="fa fa-btn fa-user"></i> close device {{$device->id}}
                </a>





        </div>



        &nbsp;   &nbsp; &nbsp;   &nbsp;



    @endforeach

    <a href="/control_on_groups">  to control on your group click here .</a>
@endsection