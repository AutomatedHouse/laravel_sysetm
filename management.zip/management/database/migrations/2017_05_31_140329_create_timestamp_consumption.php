<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTimestampConsumption extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('consumption_timestamp', function (Blueprint $table) {
            //$table->increments('id');
            //$table->timestamps();
            $table->integer('consumption_id')->unsigned();
            $table->integer('timestamp_id')->unsigned();
            $table->primary(['consumption_id','timestamp_id']);

            $table->foreign('consumption_id')->references('id')->on('consumptions');
            $table->foreign('timestamp_id')->references('id')->on('timestamps');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('timestamp_consumption');
    }
}
